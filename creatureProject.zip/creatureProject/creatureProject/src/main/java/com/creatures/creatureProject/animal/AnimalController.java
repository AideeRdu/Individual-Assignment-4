package com.creatures.creatureProject.animal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

//@RestController
@Controller
@RequestMapping("/creatures")

public class AnimalController{
    @Autowired
    private AnimalService service;

    @GetMapping("/all")
    public Object getAllAnimals(Model model){
        //return new ResponseEntity<>(service.getAllAnimals(), HttpStatus.OK);
        model.addAttribute("animalList", service.getAllAnimals());
        model.addAttribute("title", "All Animals");
        return "animals-list";
    }

    @GetMapping("/{animalId}")
    public Object getOneAnimal(@PathVariable int animalId, Model model) {
        //return new ResponseEntity<>(service.getAnimalbyID(animalId), HttpStatus.OK);
        model.addAttribute("animal", service.getAnimalbyID(animalId));
        model.addAttribute("title", "Student #: " + animalId);
        return "animals-details";
    }

    @GetMapping("/name")
    public Object getAnimalName(@RequestParam(name = "search", defaultValue = "") String search) {
        return new ResponseEntity<>(service.getAnimalByName(search), HttpStatus.OK);
    }

    @GetMapping("/description/{description}")
    public Object getAnimalDescription(@PathVariable String description) {
        return new ResponseEntity<>(service.getAnimalDescription(description), HttpStatus.OK);
    }

    @PostMapping("/new")
    public String addNewAnimal(
            @RequestParam("name") String name,
            @RequestParam("description") String description,
            @RequestParam("image") MultipartFile imageFile
    ) {
        try {
            String uploadDir = new File("creatureProject/src/main/resources/static/images").getCanonicalPath();
            String filename = imageFile.getOriginalFilename();

            File dir = new File(uploadDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            Path filepath = Paths.get(uploadDir, filename);
            System.out.println("Saving image to: " + filepath);

            Files.copy(imageFile.getInputStream(), filepath, StandardCopyOption.REPLACE_EXISTING);

            Animal animal = new Animal(name, description);
            animal.setImagePath("/images/" + filename);

            service.addNewAnimal(animal);
            return "redirect:/creatures/all";

        } catch (IOException e) {
            e.printStackTrace();
            return "An exception occurred";
        }
    }

    // goes to the web page to create a new entry
    @GetMapping("/animal-create")
    public String showCreatePage() {
        return "animal-create";
    }

//old code, do not use
//    @PutMapping("/update/{animalID}")
//    public Object updateAnimal(@PathVariable int animalID, @RequestBody Animal animal) {
//        service.updateAnimal(animalID, animal);
//        return new ResponseEntity<>(service.getAnimalbyID(animalID), HttpStatus.CREATED);
//
//    }

    // Updated form to update entry
    //new way of updating an existing animal/creature
    @PostMapping("/update")
    public String updateAnimalByName(
            @RequestParam("name") String name,
            @RequestParam("description") String description,
            @RequestParam(value = "image", required = false) MultipartFile imageFile
    ) {
        Animal existingAnimal = service.getSingleAnimalByExactName(name);

        if (existingAnimal == null) {
            return "redirect:/creatures/error";
        }

        existingAnimal.setDescription(description);

        if (imageFile != null && !imageFile.isEmpty()) {
            try {
                String uploadDir = new File("creatureProject/src/main/resources/static/images").getCanonicalPath();
                String filename = imageFile.getOriginalFilename();

                File dir = new File(uploadDir);
                if (!dir.exists()) {
                    dir.mkdirs();
                }

                Path filepath = Paths.get(uploadDir, filename);
                Files.copy(imageFile.getInputStream(), filepath, StandardCopyOption.REPLACE_EXISTING);
                existingAnimal.setImagePath("/images/" + filename);

            } catch (IOException e) {
                e.printStackTrace();
                return "redirect:/creatures/error";
            }
        }

        service.addNewAnimal(existingAnimal);
        return "redirect:/creatures/all";
    }

    //shows the animal-update web page
    @GetMapping("/animal-update")
    public String showUpdatePage() {
        return "animal-update";
    }

    // shows the animal-delete web page

    @GetMapping("/animal-delete")
    public String showDeletePage() {
        return "animal-delete";
    }

//
//    // old way of deleting that requires an ID
//    @DeleteMapping("/delete/{animalId}")
//    public Object deleteAnimalByID(@PathVariable int animalID) {
//        service.deleteAnimalByID(animalID);
//        return new ResponseEntity<>(service.getAllAnimals(), HttpStatus.OK);
//    }

    // updated way of deleting that only requires a name
    @PostMapping("/delete")
    public String deleteAnimalByName(@RequestParam("name") String name) {
        Animal existing = service.getSingleAnimalByExactName(name);
        if (existing != null) {
            service.deleteAnimalByID(existing.getAnimalID());
        }
        // redirects to main page
        return "redirect:/creatures/all";
    }

}
